import unittest
from peewee import SqliteDatabase
from models import Gifter
import datetime

test_db = SqliteDatabase(':memory:')

class TestGifterModel(unittest.TestCase):
    def setUp(self):
        test_db.bind([Gifter])
        test_db.connect()
        test_db.create_tables([Gifter])

    def tearDown(self):
        test_db.drop_tables([Gifter])
        test_db.close()

    def test_create_gifter(self):
        Gifter.create(
            user_id="12345",
            unique_id="test_user",
            nickname="Test User",
            gifter_level=35
        )
        
        gifter = Gifter.get(Gifter.user_id == "12345")
        self.assertEqual(gifter.unique_id, "test_user")
        self.assertEqual(gifter.gifter_level, 35)

    def test_high_level_query(self):
        Gifter.create(user_id="1", unique_id="u1", gifter_level=10)
        Gifter.create(user_id="2", unique_id="u2", gifter_level=40)
        Gifter.create(user_id="3", unique_id="u3", gifter_level=31)
        
        high_level = Gifter.select().where(Gifter.gifter_level > 30)
        self.assertEqual(high_level.count(), 2)

if __name__ == '__main__':
    unittest.main()
