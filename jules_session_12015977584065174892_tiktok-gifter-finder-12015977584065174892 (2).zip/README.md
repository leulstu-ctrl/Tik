# TikTok Gifter Finder

This software scans TikTok Live streams to find users with a Gifter Level above 30.

## Installation

1.  Install dependencies:
    ```bash
    pip install -r requirements.txt
    ```

2.  Initialize the database:
    ```bash
    python models.py
    ```

## Usage

### 1. Run the Scanner
To start scanning, you need to provide the usernames of active TikTok Live streamers (popular ones are best to find more users).

```bash
python scanner.py <streamer_username1> <streamer_username2> ...
```

Example:
```bash
python scanner.py tiktok live_user_123
```

The scanner will print to the console when it finds a high-level gifter and save them to `tiktok_gifters.db`.

### 2. View Results
Run the web interface to view the list of found gifters.

```bash
python app.py
```

Open your browser and go to `http://localhost:5000`.

## Notes
- The scanner requires the streamer to be currently live.
- "Gifter Level" is extracted from the `UserHonor` field in live events (Comments, Gifts, etc.).
- The database uses SQLite.

## Running on Android (Termux)

Yes, you can run this on your phone using the **Termux** app!

1.  **Install Termux** from F-Droid or Google Play Store.
2.  **Update and Install Basics**:
    ```bash
    pkg update && pkg upgrade
    pkg install python git
    ```
3.  **Clone the Repository** (or copy the files to your phone):
    ```bash
    git clone https://github.com/yourusername/tiktok-gifter-finder.git
    cd tiktok-gifter-finder
    ```
4.  **Install Dependencies**:
    ```bash
    pip install -r requirements.txt
    ```
5.  **Run the App**:
    Follow the "Usage" steps above (Initialize DB, Run Scanner, Run App).
    
    *Note: To view the web interface, open your phone's browser and go to `http://localhost:5000` while `app.py` is running in Termux.*
