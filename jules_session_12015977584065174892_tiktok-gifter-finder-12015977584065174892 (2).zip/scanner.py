import asyncio
import sys
from TikTokLive import TikTokLiveClient
from TikTokLive.events import ConnectEvent, CommentEvent, GiftEvent, LikeEvent, JoinEvent
from models import Gifter, db
import datetime

class TikTokScanner:
    def __init__(self, unique_ids):
        if isinstance(unique_ids, str):
            unique_ids = [unique_ids]
        self.unique_ids = unique_ids
        self.clients = []

    async def start(self):
        tasks = []
        for unique_id in self.unique_ids:
            client = TikTokLiveClient(unique_id=unique_id)
            self.setup_events(client)
            self.clients.append(client)
            # Create a task for each client to run concurrently
            # client.start() is an async coroutine in newer versions usually, 
            # or we wrap client.run() if it blocks. 
            # TikTokLiveClient.start() is the async method.
            tasks.append(client.start())
        
        await asyncio.gather(*tasks, return_exceptions=True)

    def setup_events(self, client: TikTokLiveClient):
        @client.on(ConnectEvent)
        async def on_connect(event: ConnectEvent):
            print(f"Connected to Room ID: {client.room_id}")

        @client.on(CommentEvent)
        async def on_comment(event: CommentEvent):
            await self.process_user(event.user)

        @client.on(GiftEvent)
        async def on_gift(event: GiftEvent):
            await self.process_user(event.user)
            # Gifts also have a 'sender' sometimes or it is the user
        
        @client.on(LikeEvent)
        async def on_like(event: LikeEvent):
            await self.process_user(event.user)

        @client.on(JoinEvent)
        async def on_join(event: JoinEvent):
            await self.process_user(event.user)

    async def process_user(self, user):
        try:
            # Check for user_honor level
            level = 0
            
            # Accessing nested protobuf fields
            if hasattr(user, 'user_honor') and user.user_honor:
                level = user.user_honor.level
            
            # If level > 30, save to DB
            if level > 30:
                unique_id = getattr(user, 'unique_id', getattr(user, 'username', 'Unknown'))
                print(f"[FOUND] {unique_id} (Level {level})")
                self.save_gifter(user, level)
            
        except Exception as e:
            # print(f"Error processing user: {e}")
            pass

    def save_gifter(self, user, level):
        try:
            # Peewee is synchronous. In a high-perf async app, we'd use peewee-async or run_in_executor
            # But for this simple scanner, it's acceptable.
            unique_id = getattr(user, 'unique_id', getattr(user, 'username', 'Unknown'))
            
            # Upsert
            Gifter.insert(
                user_id=str(user.id),
                unique_id=unique_id,
                nickname=user.nick_name,
                gifter_level=level,
                last_seen=datetime.datetime.now()
            ).on_conflict(
                conflict_target=[Gifter.user_id],
                preserve=[Gifter.unique_id, Gifter.nickname, Gifter.gifter_level, Gifter.last_seen]
            ).execute()
            
        except Exception as e:
            print(f"DB Error: {e}")

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python scanner.py <username1> [username2 ...]")
        sys.exit(1)
    
    usernames = sys.argv[1:]
    scanner = TikTokScanner(usernames)
    
    # Python 3.7+
    try:
        asyncio.run(scanner.start())
    except KeyboardInterrupt:
        pass
