from peewee import *
import datetime

db = SqliteDatabase('tiktok_gifters.db')

class BaseModel(Model):
    class Meta:
        database = db

class Gifter(BaseModel):
    user_id = CharField(unique=True) # Storing as Char to avoid large int issues if any, though peewee handles BigInt
    unique_id = CharField() # The @username
    nickname = CharField(null=True)
    gifter_level = IntegerField()
    last_seen = DateTimeField(default=datetime.datetime.now)

def initialize_db():
    db.connect()
    db.create_tables([Gifter], safe=True)
    db.close()

if __name__ == "__main__":
    initialize_db()
