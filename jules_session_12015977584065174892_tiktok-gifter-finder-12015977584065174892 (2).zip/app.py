from flask import Flask, render_template
from models import Gifter

app = Flask(__name__)

@app.route('/')
def index():
    # Fetch top gifters, sorted by level descending
    gifters = Gifter.select().order_by(Gifter.gifter_level.desc()).limit(100)
    return render_template('index.html', gifters=gifters)

if __name__ == '__main__':
    app.run(debug=True, port=5000)
